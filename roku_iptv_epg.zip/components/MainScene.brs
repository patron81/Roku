sub init()
    m.rowList = m.top.findNode("rowList")
    m.video = m.top.findNode("videoPlayer")
    m.preview = m.top.findNode("previewVideo")
    m.nowInfo = m.top.findNode("nowInfo")

    m.playlistUrl = "https://tinyurl.com/rokucanales"
    m.epgUrl = "https://www.open-epg.com/files/argentina1.xml"

    m.epgData = {}

    loadEPG()
    loadPlaylist()
end sub

sub loadEPG()
    transfer = CreateObject("roUrlTransfer")
    transfer.setUrl(m.epgUrl)
    transfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.initClientCertificates()

    xmlStr = transfer.GetToString()

    if xmlStr <> invalid
        xml = CreateObject("roXMLElement")
        xml.Parse(xmlStr)

        programs = xml.GetNamedElements("programme")

        for each p in programs
            channel = p@channel
            title = p.GetNamedElements("title")[0].GetText()

            if m.epgData[channel] = invalid
                m.epgData[channel] = []
            end if

            m.epgData[channel].Push({ title: title })
        end for
    end if
end sub

sub loadPlaylist()
    transfer = CreateObject("roUrlTransfer")
    transfer.setUrl(m.playlistUrl)
    transfer.setCertificatesFile("common:/certs/ca-bundle.crt")
    transfer.initClientCertificates()

    response = transfer.GetToString()

    if response <> invalid
        channels = parseM3U(response)
        grouped = groupByCategory(channels)
        showRows(grouped)
    end if
end sub

function parseM3U(data as string) as object
    lines = data.Split(chr(10))
    result = []
    channel = {}

    for each line in lines
        line = line.Trim()

        if line.Left(7) = "#EXTINF"
            channel = {}

            nameStart = Instr(line, ",")
            channel.name = Mid(line, nameStart + 1)

            idStart = Instr(line, "tvg-id=")
            if idStart > 0
                id = Mid(line, idStart + 8)
                id = id.Split(chr(34))[0]
                channel.id = id
            else
                channel.id = channel.name
            end if

            logoStart = Instr(line, "tvg-logo=")
            if logoStart > 0
                logo = Mid(line, logoStart + 10)
                logo = logo.Split(chr(34))[0]
                channel.logo = logo
            else
                channel.logo = ""
            end if

            groupStart = Instr(line, "group-title=")
            if groupStart > 0
                group = Mid(line, groupStart + 13)
                group = group.Split(chr(34))[0]
                channel.group = group
            else
                channel.group = "Other"
            end if

        else if line.Left(4) = "http"
            channel.url = line
            result.Push(channel)
        end if
    end for

    return result
end function

function groupByCategory(channels as object) as object
    groups = {}
    for each ch in channels
        if groups[ch.group] = invalid
            groups[ch.group] = []
        end if
        groups[ch.group].Push(ch)
    end for
    return groups
end function

sub showRows(grouped as object)
    root = CreateObject("roSGNode", "ContentNode")

    for each category in grouped
        rowNode = CreateObject("roSGNode", "ContentNode")
        rowNode.title = category

        for each ch in grouped[category]
            item = CreateObject("roSGNode", "ContentNode")
            item.title = ch.name
            item.hdPosterUrl = ch.logo
            item.streamUrl = ch.url
            item.channelId = ch.id

            rowNode.appendChild(item)
        end for

        root.appendChild(rowNode)
    end for

    m.rowList.content = root
    m.rowList.observeField("itemFocused", "onItemFocused")
    m.rowList.observeField("rowItemSelected", "onChannelSelected")
end sub

sub onItemFocused()
    row = m.rowList.rowItemFocused[0]
    col = m.rowList.rowItemFocused[1]

    item = m.rowList.content.getChild(row).getChild(col)

    m.preview.content = CreateObject("roSGNode", "ContentNode")
    m.preview.content.url = item.streamUrl
    m.preview.visible = true
    m.preview.control = "play"

    m.nowInfo.text = item.title + " - " + getNowNext(item.channelId)
end sub

function getNowNext(channelId as string) as string
    programs = m.epgData[channelId]
    if programs = invalid or programs.Count() < 2 then return "No EPG"

    return "Now: " + programs[0].title + " | Next: " + programs[1].title
end function

sub onChannelSelected()
    row = m.rowList.rowItemSelected[0]
    col = m.rowList.rowItemSelected[1]

    item = m.rowList.content.getChild(row).getChild(col)

    m.video.content = CreateObject("roSGNode", "ContentNode")
    m.video.content.url = item.streamUrl

    m.video.visible = true
    m.video.control = "play"
end sub
