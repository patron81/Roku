sub init()

	m.top.functionName = "getContent"
end sub

' **********************************************

sub getContent()

	


	feedurl = m.global.feedurl

	m.port = CreateObject ("roMessagePort")
	searchRequest = CreateObject("roUrlTransfer")
	searchRequest.setURL(feedurl)
	searchRequest.EnableEncodings(true)
	httpsReg = CreateObject("roRegex", "^https:", "")
	if httpsReg.isMatch(feedurl)
		searchRequest.SetCertificatesFile ("common:/certs/ca-bundle.crt")
		searchRequest.AddHeader ("X-Roku-Reserved-Dev-Id", "")
		searchRequest.InitClientCertificates ()
	end if
 
'print "Paso 1 de 4: Descargando lista de canales..."
	text = searchRequest.getToString()

'descargoeventos=VersidescargoEvento()

	reHasGroups = CreateObject("roRegex", "group-title\=" + chr(34) + "?([^" + chr(34) + "]*)"+chr(34)+"?,","")
	hasGroups = reHasGroups.isMatch(text)
	print hasGroups

'Aca
'if str(descargoeventos)="1" then
 ' print "Paso 2 de 4: Descargando eventos deportivos del dia"
	' datosagendastreamtp=descargarAgendaSTREAMTP()
'	datosagendala14=descargarAgendaLA14()
'End if	

	reLineSplit = CreateObject ("roRegex", "(?>\r\n|[\r\n])", "")
	reExtinf = CreateObject ("roRegex", "(?i)^#EXTINF:\s*(\d+|-1|-0).*,\s*(.*)$", "")
        reLogo = CreateObject("roRegex", "tvg-logo\=" + chr(34) + "([^" + chr(34) + "]*)", "")
	rePath = CreateObject ("roRegex", "^([^#].*)$", "")
	inExtinf = false
	con = CreateObject("roSGNode", "ContentNode")
	if not hasGroups
		group = con
	else
		groups = []
	end if
	

contador=0
            
	REM #EXTINF:-1 tvg-logo="" group-title="uk",BBC ONE HD
logo = ""
	for each line in reLineSplit.Split (text)
		if inExtinf

			maPath = rePath.Match (line)
			
			if maPath.Count () = 2
					  
				item = group.CreateChild("ContentNode")
		
				 		if Instr(1, maPath [1], "la14hd.com") > 0  then
							item.url =Eventola14(maPath [1])
							item.title=	title
						else if Instr(1, maPath [1], "youtu") > 0 then
							item.url =EventoYouTube(maPath [1])
							'item.title=	item.url
							item.title=	title
						else if Instr(1, maPath [1], "arcast.net") > 0 
							item.url =Canal10(maPath [1])
							item.title=	title
						else if Instr(1, maPath [1], "streamtp") > 0 
							item.url =DecodePlaybackURL(maPath [1])
							item.title=	title
						 else
							item.url = maPath [1]
							item.title = title
if logo <> ""
    item.HDPosterUrl = logo
    item.SDPosterUrl = logo
else
    item.HDPosterUrl = "pkg:/images/default.png"
    item.SDPosterUrl = "pkg:/images/default.png"
end if	
						End if	
						
				
				
				inExtinf = False
			end if
		end if
		
		maExtinf = reExtinf.Match (line)
maLogo = reLogo.Match(line)
logo = ""
if maLogo.Count() > 1
    logo = maLogo[1]
end if
		if maExtinf.Count () = 3
		 ' Extract logo (optional)
       
			if hasGroups
				groupName = reHasGroups.Match(line)[1]
				group = invalid
				REM Don't know why, but FindNode refused to work here
				for x = 0 to con.getChildCount()-1
					node = con.getChild(x)
					if node.id = groupName
						group = node
						exit for
					end if
				end for
				if group = invalid
					group = con.CreateChild("ContentNode")
					group.contenttype = "SECTION"
					group.title = groupName
					group.id = groupName
				end if
			end if
		
					length = maExtinf[1].ToInt ()
			if length < 0 then length = 0
			title = maExtinf[2]
			inExtinf = True
		end if
	end for

	m.top.content = con
		
end sub


function Eventola14(queEvento as string) as String

'VEr si con SUB en vez de function funciona sub GetEventoPlaybackUrl()


    
    ' Create message port and first request
    port = CreateObject("roMessagePort")


    ' Fetch the actual playback page/script
    urlTransfer2 = CreateObject("roUrlTransfer")
    urlTransfer2.setURL(queEvento)
    urlTransfer2.EnableEncodings(true)

    if Left(queEvento, 5) = "https" then
        urlTransfer2.SetCertificatesFile("common:/certs/ca-bundle.crt")
        urlTransfer2.InitClientCertificates()
    end if
	
    response = urlTransfer2.GetToString()

    if response = invalid or response = "" then
       return "Failed to retrieve playback page"
     
    end if

    ' Parse for JavaScript line: var playbackURL = "https://...m3u8";
    marker = "var playbackURL = "
    if Instr(1, response, marker) > 0 then
        parts = response.Split(marker)
        if parts.Count() > 1 then
            segment = parts[1].Split(";")
            playbackUrl = segment[0].Replace(Chr(34), "") ' Remove double quotes
           	return playbackUrl
        else
            return "Marker found, but content malformed"
        end if
    else
        return "Playback marker not found in content"
  
    end if

	

End function

function Canal10(queEvento as string) as String

'VEr si con SUB en vez de function funciona sub GetEventoPlaybackUrl()


    
    ' Create message port and first request
    port = CreateObject("roMessagePort")


    ' Fetch the actual playback page/script
    urlTransfer2 = CreateObject("roUrlTransfer")
    urlTransfer2.setURL(queEvento)
    urlTransfer2.EnableEncodings(true)

    if Left(queEvento, 5) = "https" then
        urlTransfer2.SetCertificatesFile("common:/certs/ca-bundle.crt")
        urlTransfer2.InitClientCertificates()
    end if
	
    response = urlTransfer2.GetToString()

    if response = invalid or response = "" then
       return "Failed to retrieve playback page"
     
    end if

    ' Parse for JavaScript line: var playbackURL = "https://...m3u8";
    marker = "source src="
    if Instr(1, response, marker) > 0 then
        parts = response.Split(marker)
        if parts.Count() > 1 then
            segment = parts[1].Split(" type")
            playbackUrl = segment[0].Replace(Chr(34), "") ' Remove double quotes
            return playbackUrl
        else
            return "Marker found, but content malformed"
        end if
    else
        return "Playback marker not found in content"
  
    end if

	

End function


function EventoYouTube(queEvento as string) as String
    
    ' Create message port and first request
    port = CreateObject("roMessagePort")


    ' Fetch the actual playback page/script
    urlTransfer2 = CreateObject("roUrlTransfer")
    urlTransfer2.setURL(queEvento)
    urlTransfer2.EnableEncodings(true)

    if Left(queEvento, 5) = "https" then
        urlTransfer2.SetCertificatesFile("common:/certs/ca-bundle.crt")
        urlTransfer2.InitClientCertificates()
		'urlTransfer2.AddHeader("User-Agent", "Roku/DVP-1.0")
        'urlTransfer2.AddHeader("Accept", "text/html")
    end if
	
    response = urlTransfer2.GetToString()

    if response = invalid or response = "" then
       return "Failed to retrieve playback page"
     
    end if

    ' Parse for JavaScript line: var playbackURL = "https://...m3u8";
     marker = "hlsManifestUrl"":"""
    if Instr(1, response, marker) > 0 then
        parts = response.Split(marker)
        segment = parts[1].Split(",")
        playbackUrl = segment[0].Replace(Chr(34), "") ' Remove double quotes
        return playbackUrl
        else
        return "Marker found, but content malformed"
     End if
  
End function

function DecodePlaybackURL(paginaSTP as string) as String
    ' Initialize the array (partial shown, insert your full array here)
	paginaSTP=paginaSTP.replace("global1","global2")
	texto=BajarPagina(paginaSTP)


     jV=Valorjv(texto)

jV = SortByIndex(jV)
    k = valork(texto)
    playbackURL = ""

    for each pair in jV
        encoded = pair[1]
        decoded = Base64Decode(encoded)
       digitsOnly = RemoveNonDigits(decoded)
        if digitsOnly <> "" then
            charCode = val(digitsOnly) - k
            playbackURL = playbackURL + chr(charCode)
        end if
    end for

   

    ' Optional: Write to a file
 '   SaveToFile("tmp:/playback_url.txt", playbackURL)

    return playbackURL
end function



function Valorjv(response as string) As object
 

    ' Parse for JavaScript line: var playbackURL = "https://...m3u8";
    marker = "[["
    if Instr(1, response, marker) > 0 then
        parts = response.Split(marker)
        if parts.Count() > 1 then
            segment = parts[1].Split(";")
		'print segment[0].Replace(Chr(34), "")
        '  playbackUrl = segment[0].Replace(Chr(34), "") ' Remove double quotes
			 playbackUrl = segment[0]
		
		
          vector=marker + playbackUrl
			myArray = playbackUrl 
			return ParseJson (vector)
		
        else
            return "Marker found, but content malformed"
        end if
    else
        return "Playback marker not found in content"
  
    end if

end function

Function valork(response as string) as integer
    marker2 = "{return "
    if Instr(1, response, marker2) > 0 then
        parts2 = response.Split(marker2)
        if parts2.Count() > 1 then
            segment2 = parts2[1].Split(";}")
		 segment3 = parts2[2].Split(";}")
		'print segment[0].Replace(Chr(34), "")
            numero1 = segment2[0].Replace(Chr(34), "") ' Remove double     
        numero2 = segment3[0].Replace(Chr(34), "") 
		return val(numero1) + val(numero2)
         else
            return "Marker found, but content malformed"
        end if
    else
        return "Playback marker not found in content"
  
    end if

End function

Function bajarpagina(queevento as string) as string

    ' Create message port and first request
    port = CreateObject("roMessagePort")


    ' Fetch the actual playback page/script
    urlTransfer2 = CreateObject("roUrlTransfer")
    urlTransfer2.setURL(queEvento)
    urlTransfer2.EnableEncodings(true)

    if Left(queEvento, 5) = "https" then
        urlTransfer2.SetCertificatesFile("common:/certs/ca-bundle.crt")
        urlTransfer2.InitClientCertificates()
    end if
	
    response = urlTransfer2.GetToString()
 
    if response = invalid or response = "" then
       return "Failed to retrieve playback page"
     
    end if
	return response
	
End function

function SortByIndex(array as Object) as Object
    n = array.count()
    for i = 0 to n - 2
        for j = 0 to n - i - 2
            if array[j][0] > array[j+1][0]
                temp = array[j]
                array[j] = array[j+1]
                array[j+1] = temp
            end if
        end for
    end for
    return array
end function


function Base64Decode(encoded as String) as String
encoded = encoded.Replace("_", "/")
   encoded = encoded.Replace("-", "+")
    ba = CreateObject("roByteArray")
    ba.FromBase64String(encoded)
    return ba.ToAsciiString()
end function

function RemoveNonDigits(s as String) as String
    result = ""
    for i = 0 to len(s)-1
        ch = mid(s, i, 1)
        if ch >= "0" and ch <= "9"
            result = result + ch
        end if
    end for
    return result
end function



function AgregarEventosSTREAMTP(group as object,jsonString as String,urltudn as string,urlfs1 as string)

	            ' Iterate over the array of events
 tituloanterior=""
	for each event in Parsejson(jsonString)

                ' Extract the properties from each event
                title = event.title
	     
' SIN MLB  ni tampoco me repita los eventos deportivos

	     if instr(title,"MLB:")=0 and title<>tituloanterior then
		 		item = group.CreateChild("ContentNode")
		    time = event.time
                category = event.category
                status = event.status
                link = event.link
                newTime = AddHoursToTime(time, 2)
				ban=0   
				if instr(link,"tudn")>0 then
				item.title=newTime + ": " + title
					item.url=urltudn
					ban=1
				else if instr(link,"fox_1_usa")>0 then
				item.title=newTime + ": " + title
					item.url=urlfs1
					ban=1
				end if
				if ban=0 then
				item.title=newTime + ": " + title
				item.url=DecodePlaybackURL(link)
				end if
				tituloanterior=title
		End if
		      
            end for
		
    
end function

function AgregarEventosLA14(group as object,jsonString as String)

	            ' Iterate over the array of events
 tituloanterior=""

   sortedData = SortArrayByTime(Parsejson(jsonString))

    ' Convert back to JSON if needed
   sortedJson = FormatJson(sortedData)

	for each event in Parsejson(sortedJson)

                ' Extract the properties from each event
                title = event.title
	     
' SIN MLB  ni tampoco me repita los eventos deportivos

	     if instr(title,"MLB:")=0 and title<>tituloanterior then
		 		item = group.CreateChild("ContentNode")
		    time = event.time
                category = event.category
                status = event.status
                link = event.link
                newTime = AddHoursToTime(time, 2)
		item.title=newTime + ": " + title
		item.url=EventoLA14(link)
		
		tituloanterior=title
		End if
		      
            end for
		
    
end function

function SortArrayByTime(arr as Object) as Object
    for i = 0 to arr.Count() - 2
        for j = i + 1 to arr.Count() - 1
            if arr[i]["time"] > arr[j]["time"]
                temp = arr[i]
                arr[i] = arr[j]
                arr[j] = temp
            end if
        end for
    end for
    return arr
end function

Function descargarAgendaSTREAMTP() as String
 port = CreateObject("roMessagePort")
eventospagina="https://streamtp11.com/eventos.json"

    ' Fetch the actual playback page/script
    urlTransfer2 = CreateObject("roUrlTransfer")
    urlTransfer2.setURL(eventospagina)
    urlTransfer2.EnableEncodings(true)

    if Left(eventospagina, 5) = "https" then
        urlTransfer2.SetCertificatesFile("common:/certs/ca-bundle.crt")
        urlTransfer2.InitClientCertificates()
    end if
	
    response = urlTransfer2.GetToString()

    if response = invalid or response = ""  or response="[]" then
       return "SINAGENDA"
     
    end if
return response
End function


Function descargarAgendaLA14() as String
 port = CreateObject("roMessagePort")
eventospagina="https://la14hd.com/eventos/json/agenda123.json"

    ' Fetch the actual playback page/script
    urlTransfer2 = CreateObject("roUrlTransfer")
    urlTransfer2.setURL(eventospagina)
    urlTransfer2.EnableEncodings(true)

    if Left(eventospagina, 5) = "https" then
        urlTransfer2.SetCertificatesFile("common:/certs/ca-bundle.crt")
        urlTransfer2.InitClientCertificates()
    end if
	
    response = urlTransfer2.GetToString()

    if response = invalid or response = ""  or response="[]" then
       return "SINAGENDA"
     
    end if
return response
End function

Function VersidescargoEvento() as String
 port = CreateObject("roMessagePort")
eventospagina="https://raw.githubusercontent.com/patron81/Roku/refs/heads/main/Evento"

    ' Fetch the actual playback page/script
    urlTransfer2 = CreateObject("roUrlTransfer")
    urlTransfer2.setURL(eventospagina)
    urlTransfer2.EnableEncodings(true)

    if Left(eventospagina, 5) = "https" then
        urlTransfer2.SetCertificatesFile("common:/certs/ca-bundle.crt")
        urlTransfer2.InitClientCertificates()
    end if
	
    response = urlTransfer2.GetToString()

    if response = invalid or response = "" then
       return "SINAGENDA"
     
    end if
return response
End function

function AddHoursToTime(timeString as String, hoursToAdd as Integer) as String
    ' Extract hours and minutes from the time string
    hours = mid(timeString, 1, 2) ' Get the hours part
    minutes = mid(timeString, 4, 2) ' Get the minutes part
    
    ' Convert hours and minutes to total minutes
    totalMinutes = (val(hours) * 60) + val(minutes)
    
    ' Add the hours to total minutes
    totalMinutes = totalMinutes + (hoursToAdd * 60)
    
    ' Calculate the new hours and minutes
    newHours = int(totalMinutes / 60) ' Get the hours part
    newMinutes = totalMinutes mod 60 ' Get the remaining minutes part
	minutos=str(newMinutes)
     if instr(minutos," 0") then
		minutos=minutos.replace(" 0","00")
		end if
    ' Handle wrapping around 24 hours (e.g., 25:00 becomes 01:00)
    newHours = newHours mod 24
    
    ' Format the new time string in "HH:MM" format
    newTime = Right("00" + str(newHours), 2) + ":" + Right("00" + minutos, 2)
   
    return newTime
end function
