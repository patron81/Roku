# SimpleIPTVRoku
A Basic Roku channel for watching IPTV on the Roku

This was forked from sudo97 
Added a few more containers to play mp4 mkv etc 

You need to enter developer mode on Roku to sideload the channel a detailed tutorial can be found here 
https://www.howtogeek.com/290787/how-to-enable-developer-mode-and-sideload-roku-apps/

There is a default playlist with a few channels that can be found on the net or you can edit the m3u with your own or your iptv providers.

Will now sort into sections


